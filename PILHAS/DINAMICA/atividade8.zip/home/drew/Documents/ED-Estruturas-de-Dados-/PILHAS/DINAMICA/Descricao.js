<div>
Vocês devem implementar as funções que vimos na aula de Pilha Dinâmica, lembrando de criar os dois arquivos (.h e .c), 
além disso implementarão as funções inserção e consulta em uma pilha dinâmica.
</div>
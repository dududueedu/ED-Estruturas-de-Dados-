void bubbleSort(int *vetor, int N);
void insertionSort(int *vetor, int N);
void selectionSort(int *vetor, int N);
void mergesort(int *v, int inicio, int fim);
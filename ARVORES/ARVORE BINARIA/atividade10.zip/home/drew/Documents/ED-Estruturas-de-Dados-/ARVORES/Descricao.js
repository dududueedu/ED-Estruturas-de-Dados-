<div>
    Vocês devem implementar as funções que vimos na aula de Árvores e Árvore Binária, lembrando de criar os dois arquivos (.h e .c),
    além disso implementarão as funções para percorrer uma árvore Em Ordem e Pós-Ordem.
</div>